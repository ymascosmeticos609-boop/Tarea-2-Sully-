// Codigo del cupon y su descuento
var codigoCupon = "DESC50";
var porcentajeDescuento = 50;

// Funcion principal que se ejecuta al hacer clic en "Guardar producto"
function guardarProducto() {

  // Tomamos los valores que escribio el usuario
  var imagen = document.getElementById("inputImagen").value;
  var titulo = document.getElementById("inputTitulo").value;
  var descripcion = document.getElementById("inputDescripcion").value;
  var precio = document.getElementById("inputPrecio").value;
  var cupon = document.getElementById("inputCupon").value;

  // Validamos que los campos obligatorios no esten vacios
  if (imagen == "" || titulo == "" || descripcion == "" || precio == "") {
    document.getElementById("mensajeError").innerText = "Por favor completa todos los campos.";
    return;
  }

  // Si todo esta bien, borramos el mensaje de error
  document.getElementById("mensajeError").innerText = "";

  // Convertimos el precio a numero
  var precioOriginal = Number(precio);
  var precioFinal = precioOriginal;
  var hayDescuento = false;

  // Si el cupon es correcto, aplicamos el 50% de descuento
  if (cupon.toUpperCase() == codigoCupon) {
    precioFinal = precioOriginal - (precioOriginal * porcentajeDescuento / 100);
    hayDescuento = true;
  }

  // Ocultamos el mensaje de "no hay productos"
  document.getElementById("mensajeVacio").style.display = "none";

  // Creamos una nueva columna para la tarjeta (para el grid de Bootstrap)
  var columna = document.createElement("div");
  columna.className = "col-12 col-sm-6";

  // Construimos el HTML de la tarjeta
  var htmlTarjeta = "";
  htmlTarjeta += "<div class='tarjeta'>";
  htmlTarjeta += "  <img src='" + imagen + "' alt='" + titulo + "' onerror=\"this.src='https://placehold.co/400x170?text=Sin+imagen'\">";
  htmlTarjeta += "  <div class='tarjeta-cuerpo'>";
  htmlTarjeta += "    <h3>" + titulo + "</h3>";
  htmlTarjeta += "    <p>" + descripcion + "</p>";
  htmlTarjeta += "    <div>";
  htmlTarjeta += "      <span class='precio-final'>$" + precioFinal.toLocaleString() + "</span>";

  // Solo mostramos el precio original y el descuento si se uso el cupon
  if (hayDescuento == true) {
    htmlTarjeta += "      <span class='precio-original'>$" + precioOriginal.toLocaleString() + "</span>";
    htmlTarjeta += "      <span class='etiqueta-descuento'>50% OFF</span>";
  }

  htmlTarjeta += "    </div>";
  htmlTarjeta += "    <button class='boton-eliminar' onclick='eliminarProducto(this)'>Eliminar producto</button>";
  htmlTarjeta += "  </div>";
  htmlTarjeta += "</div>";

  columna.innerHTML = htmlTarjeta;

  // Agregamos la tarjeta a la lista
  document.getElementById("listaProductos").appendChild(columna);

  // Limpiamos el formulario para el siguiente producto
  document.getElementById("inputImagen").value = "";
  document.getElementById("inputTitulo").value = "";
  document.getElementById("inputDescripcion").value = "";
  document.getElementById("inputPrecio").value = "";
  document.getElementById("inputCupon").value = "";
}

// Funcion para eliminar una tarjeta al hacer clic en "Eliminar"
function eliminarProducto(boton) {
  // Subimos tres niveles: boton -> tarjeta-cuerpo -> tarjeta -> columna
  var columna = boton.parentElement.parentElement.parentElement;
  columna.remove();

  // Si ya no quedan tarjetas, mostramos de nuevo el mensaje de vacio
  var lista = document.getElementById("listaProductos");
  var tarjetas = lista.querySelectorAll(".tarjeta");

  if (tarjetas.length == 0) {
    document.getElementById("mensajeVacio").style.display = "block";
  }
}
